# php-twitter
A Some like clone of twitter written in php
### Useful links:
- https://github.com/steampixel/simplePHPRouter
