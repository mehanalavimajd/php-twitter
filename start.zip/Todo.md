**Important**: must done within 2 weeks
- [X] 404 page
- [X] Trending page
- [X] logout style
- [ ] Fixing link styles in home
- [X] updating tweet style
- [X] profile page style
**Feature**: would be better if could be done
- [X] adding search option
- [ ] adding notification
- [ ] fixing security bugs(CSRF, XSS, SQLi, ...)